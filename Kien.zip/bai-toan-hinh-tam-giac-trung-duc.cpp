//#include<stdio.h>
//int main()
//{
//	int i,j,n;
//	printf("Nhap canh cua tam giac:");
//	scanf ("%d", &n);
//	for (i=1; i<=n;i++)
//	{
//		for (j=1; j<=i; j++)
//		{
//			printf ("*");
//		}
//		printf ("\n");
//	}
//	return 0;
//}

/* rong o goc phan tu thu nhat */
//#include<stdio.h>
//int main()
//{
//	int i,j,n;
//	printf("Nhap canh cua tam giac:");
//	scanf ("%d", &n);
//	for (i=1; i<=n;i++){
//		for (j=1; j<=i; j++){
//			if (j==1 || i==n || i==j)
//			printf ("*");
//			else printf(" ");
//		}
//		printf ("\n");
//	}
//	return 0;
//}


/*goc phan tu thu hai*/
//#include <stdio.h>
//int main(){
//	int i,j,n;
//	printf("Nhap do dai canh n");
//	scanf ("%d",&n);
//	for (i=1; i<=n; i++){
//		for (j=1; j<=n-i;j++){
//			printf (" ");
//		}
//		for (j=1;j<=i;j++){
//		printf ("*");
//	}
//	printf ("\n");
//	}
//	return 0;
//}


/* rong */ 

//#include <stdio.h>
//int main(){
//	int i,j,n;
//	printf("Nhap do dai canh n");
//	scanf ("%d",&n);
//	for (i=1; i<=n; i++){
//		for (j=1; j<=n;j++){
//		if(i+j==n+1|| i==n||j==n)
//		printf ("*");
//		else printf (" ");
//	}
//	printf ("\n");
//	}
//	return 0;
//}

/* goc phan tu thu 3*/

//#include <stdio.h>
//int main(){
//	int i,j,n;
//	printf("Nhap canh cua tam giac:");
//	scanf("%d", &n);
//	for (i=1; i<=n; i++){
//		for (j=1; j<i;j++){
//			printf (" ");
//		}
//		for (j=1; j<=n-i+1; j++){
//			printf ("*");
//		}
//		printf ("\n");
//	}
//	return 0;
//}

/*rong*/ 

//#include <stdio.h>
//int main(){
//	int i,j,n;
//	printf("Nhap canh cua tam giac:");
//	scanf("%d", &n);
//	for (i=1; i<=n; i++){
//		for (j=1; j<=n; j++){
//			if (i==j|| i==1 ||j==n)
//			printf ("*");
//			else printf (" ");
//		}
//		printf ("\n");
//	}
//	return 0;
//}

/* goc phan tu thu 4*/
//#include <stdio.h>
//int main(){
//	int i,j,n;
//	printf("Nhap canh cua tam giac:");
//	scanf("%d", &n);
//	for (i=1; i<=n; i++){
//		for (j=1; j<=n-i+1; j++){
//			printf ("*");
//		}
//		printf ("\n");
//	}
//	return 0;
//}

/*rong */

//#include <stdio.h>
//int main(){
//	int i,j,n;
//	printf("Nhap canh cua tam giac:");
//	scanf("%d", &n);
//	for (i=1; i<=n; i++){
//		for (j=1; j<=n; j++){
//			if (i+j == n+1|| i==1|| j==1)
//			printf ("*");
//			else printf (" ");
//		}
//		printf ("\n");
//	}
//	return 0;
//}
